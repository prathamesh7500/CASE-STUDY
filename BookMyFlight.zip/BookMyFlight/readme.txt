﻿ASP.NET MVC Book My Flight
---------------------------------
A flight booking application that lets you Search for and book flights, filter results by price and duration, or view historical bookings, manage your profile, and print invoices.

This application generates random data for flights and airlines in SQL and it uses FlexCharts, ListBox, Input, PDF controls, and Bootstrap!
Requires Visual Studio 2013.