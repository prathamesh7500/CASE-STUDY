﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBookingWebApi.Models
{
    public class FBS_ServiceLocation
    {
        public int FBS_ServiceLocation_Id { get; set; }
        [Key]
        public string FBS_LocationName { get; set; }
    }

}
